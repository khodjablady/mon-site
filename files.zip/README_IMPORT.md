# Import automatique — comment l'utiliser

1. Vérifiez que la Deploy Key (clé publique SSH) avec Write access est ajoutée au dépôt.

2. Créez ces fichiers dans le dépôt :
   - .github/workflows/import-site.yml
   - scripts/import_site.sh
   - scripts/html_to_hugo.py
   - README_IMPORT.md

3. Lancez le workflow : Actions → Import site to Hugo → Run workflow.

4. Après exécution :
   - La branche import/hugo-site sera créée et une PR ouverte.
   - Le répertoire import_site/ contiendra la version Hugo générée.
   - Vérifiez les traductions automatiques et remplacez les placeholders Snipcart/Formspree par vos clés.