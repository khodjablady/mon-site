#!/usr/bin/env bash
set -euo pipefail

SITE_URL="${SITE_URL:-https://khodja-blady-products.com}"
WORKDIR="$(pwd)/site_import"
EXPORT_DIR="${WORKDIR}/export"
HUGO_DIR="${WORKDIR}/hugo_site"

rm -rf "$WORKDIR"
mkdir -p "$EXPORT_DIR" "$HUGO_DIR"

echo "Mirror site with wget (ignoring robots.txt)..."
wget --mirror --convert-links --adjust-extension --page-requisites --no-parent --adjust-extension --span-hosts --execute robots=off --directory-prefix="$EXPORT_DIR" "$SITE_URL"

echo "Convert HTML to Hugo structure..."
python3 scripts/html_to_hugo.py --export-dir "$EXPORT_DIR" --output "$HUGO_DIR" --base-url "$SITE_URL"

echo "Prepare Hugo site and move generated content into repository..."
TARGET_DIR="imported_site_hugo"
rm -rf "$TARGET_DIR"
mkdir -p "$TARGET_DIR"
cp -r "$HUGO_DIR"/. "$TARGET_DIR"/

mkdir -p "$TARGET_DIR"/config
cat > "$TARGET_DIR"/config/snipcart_example.json <<'EOF'
{
  "snipcart": {
    "public_api_key": "VOTRE_SNIPCART_PUBLIC_API_KEY"
  },
  "formspree": {
    "endpoint": "https://formspree.io/f/your_form_id"
  }
}
EOF

ADMIN_USER="admin"
if [ -z "${ADMIN_PASSWORD:-}" ]; then
  echo "$ADMIN_USER:__GENERATE_HTPASSWD__" > "$TARGET_DIR"/security.htpasswd
else
  if command -v htpasswd >/dev/null 2>&1 ; then
    htpasswd -nbB "$ADMIN_USER" "$ADMIN_PASSWORD" > "$TARGET_DIR"/security.htpasswd
  else
    echo "$ADMIN_USER:__GENERATED_BY_WORKFLOW__" > "$TARGET_DIR"/security.htpasswd
  fi
fi

git config user.name "site-importer-bot"
git config user.email "importer@localhost"
git fetch origin
git checkout -b import/hugo-site || git switch import/hugo-site

rm -rf import_site || true
mv "$TARGET_DIR" import_site

git add import_site
git commit -m "Import site -> Hugo (initial automated import)" || true
git push --set-upstream origin import/hugo-site

PR_TITLE="Import site -> Hugo (automated)"
PR_BODY="Automated import: site mirrored, converted to Hugo multiligue. See import_site/ for generated files. Please review translations and dynamic replacements."

API_JSON=$(jq -n --arg title "$PR_TITLE" --arg head "import/hugo-site" --arg base "main" --arg body "$PR_BODY" '{title: $title, head: $head, base: $base, body: $body}')
curl -s -X POST -H "Authorization: token ${GITHUB_TOKEN}" -H "Accept: application/vnd.github.v3+json" \
  "https://api.github.com/repos/${GITHUB_REPOSITORY}/pulls" -d "$API_JSON" || true

echo "Import script finished."