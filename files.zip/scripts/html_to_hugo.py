#!/usr/bin/env python3
import argparse
import os
import shutil
from pathlib import Path
from markdownify import markdownify
from bs4 import BeautifulSoup
import yaml
import re

def guess_lang_from_path(path, base_url):
    parts = [p for p in path.parts if p and p != '.' ]
    if len(parts) >= 1:
        first = parts[0]
        if re.fullmatch(r'[a-z]{2}(-[A-Z]{2})?', first):
            return first
    return 'en'

def write_hugo_content(output, lang, slug, title, md):
    content_dir = Path(output) / 'content' / lang / slug
    content_dir.mkdir(parents=True, exist_ok=True)
    front = {
        'title': title or slug,
        'date': '',
        'draft': False,
        'slug': slug
    }
    with open(content_dir / 'index.md', 'w', encoding='utf-8') as f:
        f.write('---\n')
        yaml.safe_dump(front, f, allow_unicode=True)
        f.write('---\n\n')
        f.write(md)

def convert_file(html_path, export_dir, output_dir, base_url):
    rel = html_path.relative_to(export_dir)
    lang = guess_lang_from_path(rel, base_url)
    if html_path.name.lower() in ('index.html', 'index.htm'):
        slug = rel.parent.name or 'home'
    else:
        slug = html_path.stem
    with open(html_path, 'r', encoding='utf-8', errors='ignore') as fh:
        soup = BeautifulSoup(fh, 'html.parser')
    title_tag = soup.find('title')
    title = title_tag.string.strip() if title_tag and title_tag.string else slug
    main = soup.find('main')
    body_html = str(main) if main else str(soup)
    md = markdownify(body_html, heading_style="ATX")
    write_hugo_content(output_dir, lang, slug, title, md)

def copy_static(export_dir, output_dir):
    static_out = Path(output_dir) / 'static'
    static_out.mkdir(parents=True, exist_ok=True)
    for root, dirs, files in os.walk(export_dir):
        for name in files:
            p = Path(root) / name
            if p.suffix.lower() not in ['.html', '.htm']:
                rel = p.relative_to(export_dir)
                dest = static_out / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(p, dest)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--export-dir', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--base-url', required=False, default='')
    args = parser.parse_args()
    export = Path(args.export_dir)
    out = Path(args.output)
    copy_static(export, out)
    for html in export.rglob('*.html'):
        try:
            convert_file(html, export, out, args.base_url)
        except Exception as e:
            print("Error converting", html, e)

if __name__ == '__main__':
    main()